﻿#pragma once
#include <service/blik_zay.hpp>

class [[[PROJNAME]]]Data : public ZayObject
{
public:
    [[[PROJNAME]]]Data();
    ~[[[PROJNAME]]]Data();

public:
};
